#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include<stdbool.h>	    /* bool */

typedef int pid_t;
void syscall_init (void);

void halt(void);					    /* SYS_HALT */
void exit(int status);					    /* SYS_EXIT */
pid_t exec(const char *cmd);				    /* SYS_EXEC */
int wait(pid_t pid);					    /* SYS_WAIT */
int read(int fdnum, void *buf, unsigned size);		    /* SYS_READ */
int write(int fdnum, const void *buf, unsigned size);	    /* SYS_WRITE */
int fibonacci (int n);					    /* SYS_FIBO */
int sum_of_four_int(int a, int b, int c, int d);	    /* SYS_FOURSUM */

bool create(const char *file, unsigned init_size);	    /* SYS_CREATE */
bool remove(const char *file);				    /* SYS_REMOVE */
int open(const char *file);				    /* SYS_OPEN */
int filesize(int fdnum);				    /* SYS_FILESIZE */
void seek(int fdnum, unsigned pos);			    /* SYS_SEEK */
unsigned tell(int fdnum);				    /* SYS_TELL */
void close(int fdnum);					    /* SYS_CLOSE */

#endif /* userprog/syscall.h */
