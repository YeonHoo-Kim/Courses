#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "devices/shutdown.h"	/* shutdown_power_off() */
#include "userprog/process.h"	/* process_execute(), process_wait() */
#include "devices/input.h"	/* input_getc() */
#include "threads/vaddr.h"	/* PHYS_BASE */

#include "filesys/filesys.h"	/* filesys_ functions*/
#include "filesys/file.h"	/* file_ functions*/ 
#include "filesys/off_t.h"	/* off_t */
#include "threads/synch.h"	/* lock_ functions */

static void syscall_handler (struct intr_frame *);

struct lock lock_file;		/* lock_acquire, lock_release */

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  lock_init(&lock_file);
}

struct file{			/* filesys/file.c - file access at kernel*/
  struct inode *inode;
  off_t pos;
  bool deny_write;
};

static void
syscall_handler(struct intr_frame *f UNUSED) 
{
  int *esp = f->esp;
  //printf ("system call!\n");
  
  // check for invalid pointers
  if(!is_user_vaddr(f->esp))
      exit(-1);

  /* debug */
  //printf("\nsyscall : %d\n", *(uint32_t*)(f->esp));
  //hex_dump(f->esp, f->esp, 100, 1);

  /* system call */
  switch(*(uint32_t*)(f->esp)){

      /* Projects 2 and later  */
      case SYS_HALT:
	  halt();
	  break;
      case SYS_EXIT:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  exit(esp[1]);
	  break;
      case SYS_EXEC:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  f->eax = exec((const char*)esp[1]);
	  break;
      case SYS_WAIT:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  f->eax = wait((pid_t)esp[1]);
	  break;
      case SYS_CREATE:
	  if (!is_user_vaddr(f->esp + 4) || !is_user_vaddr(f->esp + 8))
	      exit(-1);
	  f->eax = create((const char*)esp[1], (unsigned)esp[2]);
	  break;
      case SYS_REMOVE:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  f->eax = remove((const char*)esp[1]);
	  break;
      case SYS_OPEN:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  f->eax = open((const char*)esp[1]);
	  break;
      case SYS_FILESIZE:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  f->eax = filesize((int)esp[1]);
	  break;
      case SYS_READ:
	  if (!is_user_vaddr(f->esp + 4) || !is_user_vaddr(f->esp + 8) || !is_user_vaddr(f->esp + 12))
	      exit(-1);
	  f->eax = read(esp[1], (void*)esp[2], (unsigned)esp[3]);
	  break;
      case SYS_WRITE:
	  if (!is_user_vaddr(f->esp + 4) || !is_user_vaddr(f->esp + 8) || !is_user_vaddr(f->esp + 12))
	      exit(-1);
	  f->eax = write(esp[1], (void*)esp[2], (unsigned)esp[3]);
	  break;
      case SYS_SEEK:
	  if (!is_user_vaddr(f->esp + 4) || !is_user_vaddr(f->esp + 8))
	      exit(-1);
	  seek((int)esp[1], (unsigned)esp[2]);
	  break;
      case SYS_TELL:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  f->eax = tell((int)esp[1]);
	  break;
      case SYS_CLOSE:
	  if (!is_user_vaddr(f->esp + 4))
	      exit(-1);
	  close((int)esp[1]);
	  break;
    
      /* Project 3 and optionally Project 4 */
      case SYS_MMAP:
	  break;
      case SYS_MUNMAP:
	  break;

      /* Project 4 only. */
      case SYS_CHDIR:
	  break;
      case SYS_MKDIR:
	  break;

      /* Additional system calls */
      case SYS_FIBO:
	  f->eax = fibonacci(esp[1]);
	  break;
      case SYS_FOURSUM:
	  f->eax = sum_of_four_int(esp[1], esp[2], esp[3], esp[4]);
	  break;
  }
}

void halt(){
    shutdown_power_off();
}

void exit(int status){
    int i=3;
    char *name, *tok;
    name = strtok_r((char *)thread_name(), " ", &tok);
   
    if(status < 0)
	status = -1;

    thread_current()->exit_status = status;    
    while (thread_current()->fd[i] != NULL && i < 128) {
	close(i);
	i++;
    }
    printf("%s: exit(%d)\n", name, status);
    thread_exit();
}

pid_t exec(const char *cmd){
    return process_execute(cmd);
}

int wait(pid_t pid){
    return process_wait((tid_t)pid);
}

int read(int fdnum, void *buf, unsigned size){
    unsigned i;
    int ret;
    if(buf>=PHYS_BASE)
	exit(-1);

    if(fdnum == 0){
	lock_acquire(&lock_file);
	for(i=0; i<size; i++)
	    *(uint8_t*)(buf+i) = input_getc();
	lock_release(&lock_file);
	if(i == size)
	    return size;
	else
	    return -1;
    }
    else if(fdnum > 2 && fdnum < 128){
	lock_acquire(&lock_file);
	ret = file_read(thread_current()->fd[fdnum], buf, size);
	lock_release(&lock_file);
	return ret;
    }
    else
	return -1;
}

int write(int fdnum, const void *buf, unsigned size){
    
    int ret;

    if(buf>=PHYS_BASE)
	exit(-1);
    
    if(fdnum == 1){
	lock_acquire(&lock_file);
	putbuf(buf, size);
	lock_release(&lock_file);
	return size;
    }
    else if(fdnum > 2 && fdnum < 128){
	if(thread_current()->fd[fdnum] == NULL)
	    exit(-1);
	//if(thread_current()->fd[fdnum]->deny_write)
	//    file_deny_write(thread_current()->fd[fdnum]);
	lock_acquire(&lock_file);
	ret = file_write(thread_current()->fd[fdnum], buf, size);
	lock_release(&lock_file);
	return ret;
    }
    else
	return -1;
}

int fibonacci (int n){
  int i;
  int f0 = 0, f1 = 1, f2 = 1;
  if(n == 0)
     return f0;
  else if(n == 1)
     return f1;
  else{
    for(i=0;i<n-1;i++){
	f2 = f0+f1;
	f0=f1;
	f1=f2;
    }
    return f2;
  }
}

int sum_of_four_int(int a, int b, int c, int d){
  return a+b+c+d;
}

bool create(const char *file, unsigned init_size){
  if(file == NULL)
      exit(-1);
  else
      return filesys_create(file, init_size);
}

bool remove(const char *file){
  if(file == NULL)
      exit(-1);
  else
      return filesys_remove(file);
}

int open(const char *file){ 
  int i, j=0;
  char cmd_name[256];
  struct file *fp;
  while (thread_current()->name[j] != '\0' && thread_current()->name[j] != ' ') {
	  cmd_name[j] = thread_current()->name[j];
	  j++;
  }
  cmd_name[j] = '\0';
  if(file == NULL)
    return -1;
  lock_acquire(&lock_file);
  fp = filesys_open(file);
  //lock_release(&lock_file);
  if(fp == NULL){
    lock_release(&lock_file);
    return -1;
  }
  for(i=3;i<128;i++){
    if(thread_current()->fd[i] == NULL){
      if(strcmp(cmd_name, file) == 0){
       //if(strcmp(thread_name(), file) == 0){
        file_deny_write(fp);
      }
      thread_current()->fd[i] = fp;
      lock_release(&lock_file);
      return i;	
    }
  }
  lock_release(&lock_file);
  return -1;
}

int filesize(int fdnum){
  return file_length(thread_current()->fd[fdnum]);
}

void seek(int fdnum, unsigned pos){
  file_seek(thread_current()->fd[fdnum], pos);
}

unsigned tell(int fdnum){
  return file_tell(thread_current()->fd[fdnum]);
}

void close(int fdnum){
  struct file *fp;
  if(thread_current()->fd[fdnum] == NULL)
     exit(-1);
  fp = thread_current()->fd[fdnum];
  thread_current()->fd[fdnum] = NULL;	// close more than one times 
  file_close(fp);
}
