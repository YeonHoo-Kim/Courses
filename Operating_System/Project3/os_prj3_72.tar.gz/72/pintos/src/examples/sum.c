#include <stdio.h>
#include <stdlib.h>
#include "userprog/syscall.h"

int main(int argc, char *argv[]){

    int a,b,c,d;

    if(argc == 5){
      a=atoi(argv[1]);
      b=atoi(argv[2]);
      c=atoi(argv[3]);
      d=atoi(argv[4]);
      printf("%d %d\n", fibonacci(a), sum_of_four_int(a,b,c,d));
      return 0;
    }
    exit(-1);
}
